Text taken from
https://americanliterature.com/author/o-henry/short-story/what-you-want