from typing import List
import statistics
import re


def make_raw_unique(raw_text: str) -> List[str]:
    return raw_text.split()

def make_processed_unique(raw_text: str) -> List[str]:

    # Assume words with capital letter to have the same meaning
    # as the lower case words
    raw_text = raw_text.lower()

    # Split word by space then clean each individual word
    raw_text = raw_text.split()
    for idx, word in enumerate(raw_text):
        cleaned_word = ""
        for c in word:
            if c in "qwertyuiopasdfghjklzxcvbnm":
                cleaned_word += c
        raw_text[idx] = cleaned_word

    return raw_text

def make_processed_plus_unique(raw_text: str) -> List[str]:

    # Assume words with capital letter to have the same meaning
    # as the lower case words
    raw_text = raw_text.lower()

    # Split word by space then replace non-alphabet with space
    # and split again
    processed = []
    raw_text = raw_text.split()
    for idx, word in enumerate(raw_text):
        cleaned_word = ""
        for c in word:
            if c in "qwertyuiopasdfghjklzxcvbnm-":
                cleaned_word += c
        
        for word in cleaned_word.split("-"):
            processed.append(word)

    return processed


class WordStatistics(object):
    
    def __init__(self, word_list: List[str]):
        self.wl = word_list

        # Keep track of the number of times a word
        # is encountered
        self.word_dict: dict = dict()
        for word in word_list:
            amt: int = self.word_dict.get(word, 0)
            amt += 1
            self.word_dict[word] = amt
        
        # Keep track of words encountered by number
        # by encounter rate
        self.count_dict: dict = dict()
        for word, amount in self.word_dict.items():
            arr = self.count_dict.get(amount, list())
            arr.append(word)
            self.count_dict[amount] = arr
        
        return
    
    def summarize(self) -> None:

        show_words = 5

        print("--- Word List Summary ---")
        print("Raw word count:", len(self.wl))
        print("Unique word count:", len(self.word_dict))

        print(f"Top {show_words} repeated word(s):")
        _mrp = sorted(self.count_dict.items(), key=lambda x: x[0], reverse=True)
        count = 1
        for appearance_count, word in _mrp:
            print(f"- {word} appeared {appearance_count} time(s)")
            if count >= show_words:
                break
            count += 1
        
        print(f"Top {show_words} longest word(s):")
        _mlw = sorted(self.word_dict.keys(), key=lambda w: len(w), reverse=True)
        count = 1
        for word in _mlw:
            print(f"- {word} at {len(word)} character(s)")
            if count >= show_words:
                break
            count += 1

        print(f"Average word length:", statistics.mean(self.word_dict.values()))

        mode_amt = statistics.mode(self.word_dict.values())
        print(f"Appearance mode:", mode_amt)
        count = 1
        for word in self.count_dict[mode_amt]:
            print("-", word)
            if count >= 3:
                break
            count += 1

        return


rtext = ""
with open("source.txt", "r") as tmpf:
    rtext = tmpf.read()

print("Simple spliting")
WordStatistics(make_raw_unique(rtext)).summarize()
print()

print("Lower case + ignore non-alphabets")
WordStatistics(make_processed_unique(rtext)).summarize()
print()

print("Lower case + split '-' + ignore non-alphabets")
WordStatistics(make_processed_plus_unique(rtext)).summarize()
print()